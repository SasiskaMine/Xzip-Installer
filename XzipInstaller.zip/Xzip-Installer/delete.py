import shutil
import os

def remove_folder(folder_path):
    """Removes a folder and its contents recursively. Handles potential errors gracefully."""
    try:
        shutil.rmtree(folder_path)
        print(f"Folder '{folder_path}' and its contents removed successfully.")
        return True
    except FileNotFoundError:
        print(f"Error: Folder '{folder_path}' not found.")
        return False
    except OSError as e:
        print(f"Error removing folder '{folder_path}': {e}")
        return False


script_dir = os.path.dirname(os.path.abspath(__file__))  


folder_to_delete = os.path.join(script_dir, "Downloads")

if remove_folder(folder_to_delete):
    print("Folder removed.")
else:
    print("Failed to remove folder.")

