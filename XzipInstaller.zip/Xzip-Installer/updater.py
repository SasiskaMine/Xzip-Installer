import zipfile
import os
import requests


print("Xzip Installer (Updater)")

def read_txt_file(filepath):
    """Читает весь текст из TXT файла и возвращает его как строку."""
    try:
        with open(filepath, 'r', encoding='utf-8') as file:
            text = file.read()
            return text
    except FileNotFoundError:
        print(f"Ошибка: Файл не найден по пути {filepath}")
        return None
    except Exception as e:
        print(f"Произошла ошибка при чтении файла: {e}")
        return None

def unzip_to_folder(zip_filepath, destination_folder):
    """Распаковывает архив в указанную папку."""
    try:
        with zipfile.ZipFile(zip_filepath, 'r') as zip_ref:
            os.makedirs(destination_folder, exist_ok=True)
            zip_ref.extractall(destination_folder)
    except FileNotFoundError:
        print(f"Ошибка: ZIP-архив не найден по пути {zip_filepath}")
        return False 
    except zipfile.BadZipFile:
        print(f"Ошибка: Неверный формат ZIP-архива по пути {zip_filepath}")
        return False
    except Exception as e:
        print(f"Произошла непредвиденная ошибка: {e}")
        return False
    return True 


if __name__ == "__main__":
    script_dir = os.path.dirname(os.path.abspath(__file__))

    archive_name = "https://github.com/SasiskaMine/Xzip-Installer/blob/download/Installer.py"

    license_filepath = os.path.join(script_dir, "Data/updater.txt") 
    license_text = """
    При обнавление мы не обещаем что загруженый файл будет работать!
    Package URL = https://raw.githubusercontent.com/SasiskaMine/Xzip-Installer/download/Installer.py

"""

    if license_text:
        print("\nИнформация:\n", license_text)
        print("Вы согласны с Устоновкой обновления? (Y/N):")
        answer = input().upper()

    if answer == "Y":
        url = "https://raw.githubusercontent.com/SasiskaMine/Xzip-Installer/download/Installer.py" 
        try:
            response = requests.get(url, stream=True)
            response.raise_for_status()

            installer_filepath = os.path.join(script_dir, "Installer.py")  
            with open(installer_filepath, 'wb') as f:  
                for chunk in response.iter_content(chunk_size=8192):
                    f.write(chunk)

            print("Обновление установлено! Для запуска снова зайдите в Installer.py ")


        except requests.exceptions.RequestException as e:
            print(f"Ошибка при скачивании файла: {e}")

    input("Для закрытия устовновки нажмите Enter")

